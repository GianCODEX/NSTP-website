<?php ?>

<html>
<head>
<link rel="stylesheet" href="../css/choose.css">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

</head>

<body>

     <header class="header">
        <h1>Barangay Balintawak, Lipa City</h1>
        <a class="logout" href="index.php">LOG OUT</a>
    </header>

   

<div class="container">
    <h2>Anong dokumento ang kailangan?</h2>
    <a class="offset-link" href="../pages/barangay/index.php">Clearance</a>
    <a class="offset-link" href="/pages/document/businesspermi.html">Business Permit</a>
    <a class="offset-link" href="../pages/barangay/index.php">Indigency</a>
    <a class="offset-link" href="/pages/document/residency.html">Residency</a>
    <a class="offset-link" href="/pages/document/noincome.html">No Income / Low Income</a>
</div>



</body>

</html>