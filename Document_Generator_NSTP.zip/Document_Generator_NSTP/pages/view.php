<!DOCTYPE html>
<html>
<head>
    <title>Barangay Indigency Records</title>
    <link rel="stylesheet" href="../css/viewStyle.css">
</head>
<body>

<div class="container">

    <!-- ===== SIDEBAR ===== -->
    <div class="sidebar">
        <h2>Barangay Balintawak</h2>
        <a href="choose.php"> Home </a>
        <a href="aboutus.php"> About Us </a>
        <a href="index.php"> Logout </a>
    </div>

        <div class="sidebar Request">
            <h3>Requests</h3>

            <?php
            include "db.php";

            $result = mysqli_query(
                $conn,
                "SELECT id, last_name, first_name, middle_initial FROM indigency_requests ORDER BY id DESC"
            );

            while ($row = mysqli_fetch_assoc($result)) {
                echo "
                <a class='panel' href='?view_id={$row['id']}'>
                    {$row['last_name']}, {$row['first_name']} {$row['middle_initial']}
                </a>
                ";
            }
            ?>
        </div>

    <!-- ===== MAIN CONTENT ===== -->
    <div class="main">

        <h2>Indigency Records</h2>

        <!-- ===== SEARCH FORM ===== -->
        <form method="GET" class="search-form">
            <input type="text" name="search" placeholder="Search full name"
                   value="<?= $_GET['search'] ?? '' ?>">
            <button type="submit">🔍 Search</button>
        </form>

        <?php
        // ===== SEARCH LOGIC =====
        $where = "1";

        if (!empty($_GET['search'])) {
            $search = mysqli_real_escape_string($conn, $_GET['search']);
            $where .= " AND 
                last_name LIKE '%$search%'
                OR first_name LIKE '%$search%'
                OR middle_initial LIKE '%$search%'";    
        }

        $records = mysqli_query(
            $conn,
            "SELECT * FROM indigency_requests WHERE $where ORDER BY id DESC"
        );
        ?>

        <!-- ===== RECORDS TABLE ===== -->
        <table class="records-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Purok</th>
                    <th>Status</th>
                    <th>Requested At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($records)) { ?>
                <tr>
                    <td><?= $row['last_name'] ?>, <?= $row['first_name'] ?> <?= $row['middle_initial'] ?></td>
                    <td><?= $row['age'] ?></td>
                    <td><?= $row['purok'] ?></td>
                    <td>
                        <span class="status pending">Pending</span>
                    </td>
                    <td><?= date('F j, Y g:i A', strtotime($row['created_at'])) ?></td>
                    <td>
                        <a href="?view_id=<?= $row['id'] ?>">👁 View</a>
                        <a href="edit.php?id=<?= $row['id'] ?>">✏ Edit</a>
                        <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this record?');">🗑 Delete</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>

        <!-- ===== VIEW RECORD ===== -->
        <?php
        if (isset($_GET['view_id'])) {
            $id = intval($_GET['view_id']);
            $view = mysqli_query(
                $conn,
                "SELECT * FROM indigency_requests WHERE id=$id"
            );
            $data = mysqli_fetch_assoc($view);
        ?>
            <div class="record-view">
                <h3>Record Details</h3>
                <p><strong>Name:</strong> <?= $data['last_name'] ?>, <?= $data['first_name'] ?> <?= $data['middle_initial'] ?></p>
                <p><strong>Age:</strong>
                <?php if ($data['age'] < 18): ?>
                    <span style="color: #dc2626; font-weight: bold;"><?= $data['age'] ?> * Underage</span>
                <?php else: ?>
                    <span style="color: #16a34a; font-weight: bold;">
                        <?= $data['age'] ?>
                    </span>
                    <?php endif; ?>
                </p>
                <p><strong>Citizenship:</strong> <?= $data['citizenship'] ?></p>
                <p><strong>Purok:</strong> <?= $data['purok'] ?></p>
                <p><strong>Purpose:</strong> <?= $data['purpose'] ?></p>
                <p><strong>Requested At: </strong> <?= date('F j, Y g:i A', strtotime($data['created_at'])) ?></p>
                <a href="barangay/certificate.php?id=<?= $data['id'] ?>" target="_blank">
                    <button class="btn-print" style="margin-top: 10px; background: #2563eb; color: white; padding: 8px 12px; border: none; border-radius: 4px;">Print Certificate</button>
            </div>
        <?php } ?>

    </div>
</div>

</body>
</html>