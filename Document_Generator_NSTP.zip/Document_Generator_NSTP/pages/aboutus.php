<html>
    <head>
        <link rel="stylesheet" href="../css/aboutus.css">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    </head>

    <body>

        <div class="main-container">
        <div class="container-left">
            <h1>About Us!</h1>

            <p>We are a group of NSTP 1 students from National University Lipa who aim to support community service through practical and accessible technology. Our team is composed of students from different committees working together to design solutions that help improve everyday processes at the barangay level.</p>
            <br>
            <p>This project was developed as part of our NSTP requirement, with the goal of applying basic technical skills to address real community needs. By combining planning, documentation, and system development, we aim to create a solution that is simple, useful, and easy to adopt.</p>
        
            <h2><br>Professor: Jiselle Umali</h2>
            <h4>Leader: Nazareth Jay Laig</h4>
            <h4>Assistant Leader: Franchezka Denise Santiago</h4>

            <h2><br>Committees:</h2>
            <h3>Technical / Coding</h3>
            <h4>Leader - Nazareth Jay Laig</h4>
            <h4>Assistant Leader - Gian Ross Corpuz</h4>
            <h5><br>Members:<br>
                Batac, Manuel Ricardo M.<br>
                Morales, Kyle Benedict S.<br>
                Pamplona, Hanna Lei M.<br>
                Reyes, John Michael</h7>

            <h3><br>Documentation</h3>
            <h4>Leader - Franchezka Denise Santiago</h4>
            <h4>Assistant Leader - Dhara Mari Balba</h4>
            <h5><br>Members:<br>
                Roxas, Margia Sanchyna C.<br>
                Agulto, Angelo Zeus Andrei M.<br>
                Dinglasan, France Louie M.<br>
                Abuyo, Sebastian Y.<br>
                Villanueva, Migz Andrei M.<br>
                Daitol, Fyn Ezekial A.<br>
                Mercado, Jp Cyrus M.<br>    
                Castillo, Jansel Cade G.</h5>

            <h3><br>Seminar</h3>
            <h4>Leader - Princess Alshe Silva </h4>
            <h4>Assistant Leader - Bo Daimley Libramonte</h4>
            <h5><br>Members:<br>
                Visperas, Daniella Franchesca<br>
                Pangilinan, Lemuel<br>
                Exconde, Reiiel<br>
                Castillo, John Patrick<br>
                Recinto, Christian Ken <br>
              
        
        </div>

        <div class="container-right">

        </div>
        </div>


    </body>
</html>