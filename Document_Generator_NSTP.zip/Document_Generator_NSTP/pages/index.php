<!DOCTYPE html>
<html land="en">
    <head>
        <meta charset="UTF-8">
        <title>Login Page</title>
        <link rel="stylesheet" href="../css/index.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>

        <div class="login-container">
            
            <div class="login-card">
                <img src="../src/images/" class="logo" alt ="Barangay Logo">

                <h1>Barangay Balintawak</h1>
                <h2>Lipa City, Batangas</h2>

                <h1 class="login-title">LOGIN</h1>

                <div class="form-group">
                    <label>Username</label>
                    <input type="text" id="username" placeholder="Username">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" placeholder="Password">
                </div>
                
                <button class="button" onclick="login()"><a href="../pages/choose.php">LOGIN</a></button>

                <div class="error" id="error-msg">Username or password is incorrect! Please try again.</p>
                </div>

                <div>
                    <img src="../src/images/" alt="NU Lipa" class="logo">
                    <div class="footer-text">Powered by COM251 NSTP GROUP 1</div>
                </div>
            </div>
        

            <div class="info-panel">
                <h1>Welcome to Barangay Balintawak Document Generator</h1>
                <h2>Sangguiniang Barangay</h2>
                
                <img src="" alt="PICTURE HERE">
                
                <p><strong>Hon. Joselito S. Pagcaliwangan</strong> </p>
                <p>Punong Barangay</p>

                <br>

                <p><strong>Brgy.Kagawad</strong></p>
                <p>N/A</p>
                <p>N/A</p>
                <p>N/A</p>
                <p>N/A</p>   

            </div>
        </div>
    </body>
</html>
<script src="js/index.js"></script>