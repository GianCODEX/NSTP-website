<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="../css/generate.css">
    <title>SUCCESFULLY GENERATED</title>
    <style>
      
    </style>
  </head>
  <br />
  <br />
  <body>
    <div class="header">
      <h1>Successfully Generated!</h1>
    </div>
    <div class="content"></div>
    <div class="button">
      <button class="download">I-Download</button>
      <br />
      <br />
      <button class="print">I-Print</button>
    </div>
  </body>
  <footer>
    <div class="logo-seal">
      <img src="../src/images/balintawakseal.png" alt="Balintawak seal" />
    </div>

    <p>Powered by COM251 NSTP GROUP 1 | ABOUT US</p>

    <div class="nulogo">
      <img src="../src/images/NU LIPA.png" alt="Nu lipa" />
    </div>
  </footer>
</html>
