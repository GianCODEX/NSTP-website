<?php
include "db.php";

if (!isset($_GET['id'])) {
    header("Location: view.php");
    exit;
}

$id = intval($_GET['id']);

// Fetch current record
$result = mysqli_query($conn, "SELECT * FROM indigency_requests WHERE id=$id");
$data = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $middle_initial = mysqli_real_escape_string($conn, $_POST['middle_initial']);
    $age = intval($_POST['age']);
    $citizenship = mysqli_real_escape_string($conn, $_POST['citizenship']);
    $purok = mysqli_real_escape_string($conn, $_POST['purok']);
    $purpose = mysqli_real_escape_string($conn, $_POST['purpose']);

    $update = "UPDATE indigency_requests SET
               last_name='$last_name',
               first_name='$first_name',
               middle_initial='$middle_initial',
               age=$age,
               citizenship='$citizenship',
               purok='$purok',
               purpose='$purpose'
               WHERE id=$id";

    if (mysqli_query($conn, $update)) {
        header("Location: view.php");
        exit;
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Record</title>
    <link rel="stylesheet" href="../css/editStyle.css">
</head>
<body>
<div class="main-container">
    <h2>Edit Indigency Record</h2>
    <form method="POST">
        <label>Last Name</label>
        <input type="text" name="last_name" value="<?= $data['last_name'] ?>" required>

        <label>First Name</label>
        <input type="text" name="first_name" value="<?= $data['first_name'] ?>" required>

        <label>Middle Initial</label>
        <input type="text" name="middle_initial" maxlength="1" value="<?= $data['middle_initial'] ?>" required>

        <label>Age</label>
        <input type="number" name="age" value="<?= $data['age'] ?>" required>

        <label>Citizenship</label>
        <input type="text" name="citizenship" value="<?= $data['citizenship'] ?>" required>

        <label>Purok</label>
        <input type="text" name="purok" value="<?= $data['purok'] ?>" required>

        <label>Purpose</label>
        <textarea name="purpose" rows="3" required><?= $data['purpose'] ?></textarea>

        <button type="submit" class="btn-primary">Update Record</button>
        <a href="view.php" class="btn-secondary" style="margin-left:10px;">Cancel</a>
    </form>
</div>
</body>
</html>
