<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<link rel="stylesheet" href="../css/form.css">
<title> FORM  </title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;900&display=swap" rel="stylesheet">
<header>
    <div class="header">
       <h1> Barangay Balintawak, Lipa City </h1>
        <button class="Logout">LOG OUT</button>
    </div>
</header>
<br>
<main>
    <h1 class="info"> Ilagay ang mga detalye: </h1>
    <br>
    <h2 class="docname"> Barangay Clearance</h2>
    <br>
</main>
<body>
    <div class="row">
    <form class="input">
        <label> Pangalan: </label>
        <input type="text">
    </form>
    <form class="input">
        <label> Edad: </label>
        <input type="text">
    </form>
    </div>
    <div class="row">
    <form class="input2">
        <label> Kasarian: </label>
        <select id="gender">
            <option value="lalake"> Lalake</option>
            <option value="babae"> Babae </option>
        </select>
    </form>
    <form class="input2">
        <label>Katayuan-Sibil (Civil Status): </label>
        <select id="status">
            <option id="single">Single</option>
            <option id="married">Married</option>
            <option id="widowed">Widowed</option>
        </select>
    </form>
    </div>
    <button class="submit"> Isumite</button>
</body>
<br>
<br>
<footer>
    <div class="logo-seal">
        <img src="../src/images/balintawakseal.png" alt="Balintawak seal">
    </div>

    <p> Powered by COM251 NSTP GROUP 1 | ABOUT US</p>
  
    <div class="nulogo">
         <img src="../src/images/NU LIPA.png" alt="Nu lipa">
    </div>
</footer>
</html>